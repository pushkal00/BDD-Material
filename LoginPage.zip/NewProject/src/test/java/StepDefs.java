import org.junit.Assert;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefs {
	PageUpper pupr = new PageUpper();

@Given("^I am on the Login Page screen$")
public void i_am_on_the_Login_Page_screen() throws Exception {
    // Write code here that turns the phrase above into concrete actions
	pupr.goTo();
	Assert.assertTrue(pupr.isAt());

	System.out.println("Welcome Login Screen");
   // throw new PendingException();
}

@Given("^Open the web page login in the browser$")
public void open_the_web_page_login_html_in_the_browser() throws Exception {
    // Write code here that turns the phrase above into concrete actions
	
	System.out.println("Inside Login.html");
    //throw new PendingException();
}

@When("^Enter \"([^\"]*)\" and \"([^\"]*)\"$")
public void enter_and(String arg1, String arg2) throws Exception {
    // Write code here that turns the phrase above into concrete actions
	pupr.setFirstName(arg1);
	pupr.setLastName(arg2);
    //throw new PendingException();
}

@Then("^Onclicking submit button it must navigate to HotelBooking Page$")
public void onclicking_submit_button_it_must_navigate_to_HotelBooking_Page() throws Exception {
    // Write code here that turns the phrase above into concrete actions
	System.out.println("At Last Submit Button");
	pupr.SubmitApplication();
    //throw new PendingException();
}


}
