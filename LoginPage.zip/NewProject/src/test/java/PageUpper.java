import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class PageUpper extends PathPages{
	private static String page = "login.html";
	private static String title = "Hotel Booking";


	public PageUpper() {
		super(page, title);
		PageFactory.initElements(Browser.driver, this);
	}
	
	@FindBy(how = How.NAME,name="userName")
	private WebElement firstName;
	
	@FindBy(how = How.NAME,name="userPwd")
	private WebElement lastName;
	
	@FindBy(how = How.ID,id = "click")
	private WebElement button;
	
/*	public static void setPage(String page) {
		PageUpper.page = page;
	}

	public static void setTitle(String title) {
		PageUpper.title = title;
	}*/

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}
	
	public String getLastName() {
		return lastName.getText();
	}
	
	public String getFirstName() {
		return firstName.getText();
	}



	/*public void setButton(WebElement button) {
		this.button = button;
	}
*/
	public void SubmitApplication() {
	//	Browser.driver.findElement(By.cssSelector(".btn.btn-primary")).click();
		button.click();
	}



	
	

	
	

}
