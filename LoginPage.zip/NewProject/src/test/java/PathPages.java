public class PathPages {

	 String url = "D:\\Practice\\SpringWebServices\\NewProject\\src\\main\\webapp\\hotelbooking.html";

	 String title = "Loan Application Page";
	
	 public PathPages(String url, String title) {
		String webPageLocation = "file:///"+ System.getProperty("user.dir")+ "/src/main/webapp/";
		
		this.url = webPageLocation +  url;
		this.title = title;
	}

	public void goTo() {
		
		Browser.goTo(url);
	}

	public boolean isAt() {
		return true;
	}

	
	
}
