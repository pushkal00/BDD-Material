public class PathPages {

	 String url = "D:\\Users\\PUSGOYAL\\Desktop\\Cucumber-Selenium-POM-Demo\\src\\main\\webapp\\LoanApplicationPage.html";

	 String title = "Loan Application Page";
	
	 public PathPages(String url, String title) {
		String webPageLocation = "file:///"+ System.getProperty("user.dir")+ "/src/main/webapp/";
		
		this.url = webPageLocation +  url;
		this.title = title;
	}

	public void goTo() {
		
		Browser.goTo(url);
	}

	public boolean isAt() {
		return Browser.title().equals(title);
	}

	
	
}
