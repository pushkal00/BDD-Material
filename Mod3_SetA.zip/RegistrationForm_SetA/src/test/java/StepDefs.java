import java.awt.Button;

import org.junit.Assert;
import org.openqa.selenium.Alert;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefs {
private BeansForRegister beans;
private Browser browser;


@Before
public void testBefore() {
	browser=new Browser();
	beans =new BeansForRegister(browser);
	
}

@Given("^User is on Registration Page$")
public void user_is_on_Registration_Page() throws Exception {
	beans.goTo(browser);
	
}

@When("^User Fills the UserId invalid$")
public void user_Fills_the_UserId_invalid() throws Exception {
	beans.setUserid("123456789012334");
    
}

@When("^on clicking Submit Button$")
public void on_clicking_Submit_Button() throws Exception {
	beans.submitApplication();
}

@Then("^Check the Alert message on UserName$")
public void check_the_Alert_message_on_UserName() throws Exception {
	Alert alert = browser.driver.switchTo().alert();
	System.out.println("The alert:"+ alert.getText());
	Assert.assertTrue(alert.getText().equals("User Id should not be empty / length be between 5 to 12"));
	alert.accept();
	

}

@When("^User leaves the password empty$")
public void user_leaves_the_password_empty() throws Exception {
	
	beans.setUserid("1234567");
	beans.setPassword("");

}

@Then("^Check the Alert message on Password$")
public void check_the_Alert_message_on_Password() throws Exception {
	Alert alert = browser.driver.switchTo().alert();
	System.out.println("The alert:"+ alert.getText());
	Assert.assertTrue(alert.getText().equals("Password should not be empty / length be between 7 to 12"));
	alert.accept();

}
@When("^User enters the Empty name$")
public void user_enters_the_Empty_name() throws Exception {
	beans.setUserid("1234567");
	beans.setPassword("Password");
	beans.setUserName("");
	
}

@Then("^Check the Alert message on Username$")
public void check_the_Alert_message_on_Username() throws Exception {
	Alert alert = browser.driver.switchTo().alert();
	System.out.println("The alert:"+ alert.getText());
	Assert.assertTrue(alert.getText().equals("Name should not be empty and must have alphabet characters only"));
	alert.accept();

}

@When("^User enters the invalid Address$")
public void user_enters_the_invalid_Address() throws Exception {
	beans.setUserid("1234567");
	beans.setPassword("Password");
	beans.setUserName("Pushkal");
	beans.setAddress("");

}

@Then("^Check the Alert message on Address$")
public void check_the_Alert_message_on_Address() throws Exception {
	Alert alert = browser.driver.switchTo().alert();
	System.out.println("The alert:"+ alert.getText());
	Assert.assertTrue(alert.getText().equals("User address must have alphanumeric characters only"));
	alert.accept();

}

@When("^User does not select the country$")
public void user_does_not_select_the_country() throws Exception {
	beans.setUserid("1234567");
	beans.setPassword("Password");
	beans.setUserName("Pushkal");
	beans.setAddress("Talwade");
	beans.setCountry("(Please select a country)");


	
}

@Then("^Check the Alert message on Country$")
public void check_the_Alert_message_on_Country() throws Exception {
	Alert alert = browser.driver.switchTo().alert();
	System.out.println("The alert:"+ alert.getText());
	Assert.assertTrue(alert.getText().equals("Select your country from the list"));
	alert.accept();

}

@When("^User does not enter the Zip$")
public void user_does_not_enter_the_Zip() throws Exception {
	beans.setUserid("1234567");
	beans.setPassword("Password");
	beans.setUserName("Pushkal");
	beans.setAddress("Talwade");
	beans.setCountry("India");
	beans.setZip("wer");

	
}

@Then("^Check the Alert message on Zip$")
public void check_the_Alert_message_on_Zip() throws Exception {
	Alert alert = browser.driver.switchTo().alert();
	System.out.println("The alert:"+ alert.getText());
	Assert.assertTrue(alert.getText().equals("ZIP code must have numeric characters only"));
	alert.accept();

}

@When("^User Enters Invalid EmailId$")
public void user_Enters_Invalid_EmailId() throws Exception {
	beans.setUserid("1234567");
	beans.setPassword("Password");
	beans.setUserName("Pushkal");
	beans.setAddress("Talwade");
	beans.setCountry("India");
	beans.setZip("12345");
	beans.setEmail("GLC101");

}

@Then("^Check the Alert message on EmailId$")
public void check_the_Alert_message_on_EmailId() throws Exception {
	Alert alert = browser.driver.switchTo().alert();
	System.out.println("The alert:"+ alert.getText());
	Assert.assertTrue(alert.getText().equals("You have entered an invalid email address!"));
	alert.accept();

}

@When("^User does not select the Sex$")
public void user_does_not_select_the_Sex() throws Exception {
	beans.setUserid("1234567");
	beans.setPassword("Password");
	beans.setUserName("Pushkal");
	beans.setAddress("Talwade");
	beans.setCountry("India");
	beans.setZip("12345");
	beans.setEmail("GLC101");
	beans.setEmail("goelpushkar901@gmail.com");
}

@Then("^Check the Alert message on Sex$")
public void check_the_Alert_message_on_Sex() throws Exception {
	Alert alert = browser.driver.switchTo().alert();
	System.out.println("The alert:"+ alert.getText());
	Assert.assertTrue(alert.getText().equals("Please Select gender"));
	alert.accept();

}

@When("^User Enters the Language English as default$")
public void user_Enters_the_details() throws Exception {
	beans.setUserid("1234567");
	beans.setPassword("Password");
	beans.setUserName("Pushkal");
	beans.setAddress("Talwade");
	beans.setCountry("India");
	beans.setZip("12345");
	beans.setEmail("GLC101");
	beans.setEmail("goelpushkar901@gmail.com");
	beans.setEnglish("English");
	Thread.sleep(4000);
}


@After
public void close()
{
   browser.driver.close();	
}




}
