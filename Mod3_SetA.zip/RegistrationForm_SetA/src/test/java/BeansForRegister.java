import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class BeansForRegister extends PathPages{
	
	 private static  String page="RegistrationForm.html";
	 private  static String tittle="Welcome to JobsWorld";
	 private Browser browser;

	public BeansForRegister(Browser browser) {
		super(page, tittle);
		this.browser=browser;
		PageFactory.initElements(browser.driver, this);
	}
	@FindBy(id="usrID")
	WebElement Userid;
	
	@FindBy(id="pwd")
	WebElement password;
	
	@FindBy(id="usrname")
	WebElement UserName;
	
	@FindBy(className="Format1")
	WebElement Address;
	
	@FindBy(name="country")
	WebElement Country;
	
	@FindBy(name="zip")
	WebElement Zip;
	
	@FindBy(name="email")
	WebElement Email;
	
	@FindBy(name="gender")
	WebElement Gender;
	
	@FindBy(name="en")
	WebElement English;
	
	@FindBy(name="nonen")
	WebElement NonEnglish;
	
	@FindBy(xpath="//*[@id=\"desc\"]")
	WebElement About;
	
	@FindBy(name="submit")
	WebElement button;

	public Browser getBrowser() {
		return browser;
	}

	

	public WebElement getUserid() {
		return Userid;
	}

	public void setUserid(String  userid) {
		this.Userid.sendKeys(userid);;
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String Password) {
		this.password.sendKeys(Password);
	}

	public WebElement getUserName() {
		return UserName;
	}

	public void setUserName(String username) {
		this.UserName.sendKeys(username);
	}

	public WebElement getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		this.Address.sendKeys(address);
	}

	public WebElement getCountry() {
		return Country;
	}

	public void setCountry(String country) {
		this.Country.sendKeys(country);
	}

	public WebElement getZip() {
		return Zip;
	}

	public void setZip(String zip) {
		this.Zip.sendKeys(zip);
	}

	public WebElement getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		this.Email.sendKeys(email);

	}

	public WebElement getGender() {
		return Gender;
	}

	public void setGender(String gender) {
		this.Gender.sendKeys(gender);

	}

	public WebElement getEnglish() {
		return English;
	}

	public void setEnglish(String english) {
		this.English.sendKeys(english);

	}

	public WebElement getNonEnglish() {
		return NonEnglish;
	}

	public void setNonEnglish(String nonEnglish) {
		this.NonEnglish.sendKeys(nonEnglish);

	}

	public WebElement getAbout() {
		return About;
	}

	public void setAbout(String about) {
		this.About.sendKeys(about);

	}

	public WebElement getButton() {
		return button;
	}

	public void submitApplication()  {
		button.click();

	}



	
	

	
	

}
